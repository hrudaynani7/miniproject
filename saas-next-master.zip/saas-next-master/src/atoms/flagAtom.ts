import {atom} from 'recoil';

export const refetchCreditsAtom = atom({
    key: 'refetchCredits',
    default: false
})