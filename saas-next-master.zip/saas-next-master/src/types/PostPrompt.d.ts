interface PostPrompt{
    title: string;
    description: string;
    keywords: string;
    tone: string;
}