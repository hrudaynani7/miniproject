interface Profile{
    uid:string;
    credits:number;
}