interface Tone {
    label: string;
    value: string;
}