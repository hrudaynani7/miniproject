export const menu : MenuItem[] =[
    {
        text: "New",
        icon: "plus",
        route: "/new"
    },
    {
        text: "Posts",
        icon: "list",
        route: "/posts"
    },
    {
        text: "Profile",
        icon: "cog",
        route: "/profile"
    },
]